/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.teste_v3nus;

/**
 *
 * @author ALUNO
 */
public class Teste_V3nus {

    public static void main(String[] args) {
        new Calculadora_da_Venus().setVisible(true);
                
                
                
                
    
    }
}
